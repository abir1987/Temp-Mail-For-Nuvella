document.addEventListener('DOMContentLoaded', () => {
    // --- DOM Element References ---
    const tempEmailAddressElement = document.getElementById('temp-email-address');
    const copyButton = document.getElementById('copy-button');
    const copyButtonAlt = document.getElementById('copy-button-alt'); // Second copy button
    const refreshButton = document.getElementById('refresh-button');
    const changeButton = document.getElementById('change-button');
    const deleteButton = document.getElementById('delete-button');
    const inboxMessagesElement = document.getElementById('inbox-messages');

    let currentEmail = ''; // Variable to store the current email address

    // --- Functions ---

    /**
     * Generates a simple placeholder temporary email address.
     * In a real application, this would be fetched from the backend API.
     */
    function generateNewEmailAddress() {
        const randomPart = Math.random().toString(36).substring(2, 10); // Generate random string
        const domains = ['mongrec.com', 'tmz.com', 'mailix.xyz', 'devmail.info']; // Example domains
        const randomDomain = domains[Math.floor(Math.random() * domains.length)];
        return `${randomPart}@${randomDomain}`;
    }

    /**
     * Updates the displayed email address on the page.
     * @param {string} email - The email address to display.
     */
    function displayEmailAddress(email) {
        currentEmail = email;
        tempEmailAddressElement.textContent = currentEmail;
    }

    /**
     * Copies the current email address to the clipboard.
     */
    async function copyEmailToClipboard() {
        if (!currentEmail) {
            console.warn("No email address generated yet.");
            return;
        }
        try {
            await navigator.clipboard.writeText(currentEmail);
            console.log('Email copied to clipboard:', currentEmail);

            // Provide visual feedback on the main copy button
            const originalText = copyButton.innerHTML;
            copyButton.innerHTML = '<span class="icon-placeholder">✓</span> Copied!';
            copyButton.style.backgroundColor = '#2ecc71'; // Green color for success

            // Provide feedback on the alternate copy button as well
            const originalAltText = copyButtonAlt.innerHTML;
            copyButtonAlt.style.backgroundColor = '#ddd'; // Slightly change bg
             copyButtonAlt.innerHTML = '<span class="icon-placeholder">✓</span> Copied';


            // Revert button text after a short delay
            setTimeout(() => {
                copyButton.innerHTML = originalText;
                copyButton.style.backgroundColor = ''; // Revert to original CSS color

                copyButtonAlt.innerHTML = originalAltText;
                copyButtonAlt.style.backgroundColor = ''; // Revert to original CSS color

            }, 1500); // Revert after 1.5 seconds

        } catch (err) {
            console.error('Failed to copy email: ', err);
            // Maybe show an error message to the user here
            alert("Could not copy email to clipboard. Please try manually.");
        }
    }

    /**
     * Clears the inbox display and shows the "empty" message.
     */
    function clearInboxDisplay() {
         inboxMessagesElement.innerHTML = `
             <div class="empty-inbox">
                <div class="empty-inbox-icon">✉️</div>
                <p>Your inbox is empty</p>
                <span>Waiting for incoming emails</span>
             </div>`;
    }

    /**
     * Fetches and displays emails for the current address.
     * Placeholder - In a real app, this would fetch from the backend API.
     */
    function refreshInbox() {
        console.log('Refreshing inbox for:', currentEmail);
        // Clear existing messages (optional, depends on desired behavior)
        // clearInboxDisplay(); // Keep it empty for now

        inboxMessagesElement.innerHTML = `
             <div class="empty-inbox">
                <div class="empty-inbox-icon">⏳</div>
                <p>Checking for emails...</p>
                <span>Please wait a moment.</span>
             </div>`;


        // **Simulate API call delay**
        setTimeout(() => {
            // **Simulate finding no emails**
             clearInboxDisplay(); // Show empty message after check
            // **OR: Simulate finding emails (Example Structure)**
            /*
            const emails = [
                { id: 1, sender: 'service@example.com', subject: 'Verify Your Account', timestamp: '10:35 AM' },
                { id: 2, sender: 'newsletter@test.org', subject: 'Your Weekly Update', timestamp: '10:32 AM' }
            ];
            displayEmails(emails); // You would need to create this function
            */
            console.log('Inbox refresh simulation complete.');
        }, 2000); // Simulate 2 seconds network request
    }

    /**
     * Handles the 'Change' button click. Generates a new email.
     */
    function changeEmailAddress() {
        console.log('Changing email address...');
        const newEmail = generateNewEmailAddress();
        displayEmailAddress(newEmail);
        clearInboxDisplay(); // Clear inbox for the new address
        console.log('New email generated:', newEmail);
        alert('New temporary email address generated!'); // Simple user feedback
    }

    /**
     * Handles the 'Delete' button click. Clears the current email.
     */
    function deleteEmailAddress() {
        console.log('Deleting email address:', currentEmail);
        alert(`Email address ${currentEmail} will be deleted (simulation).`); // User feedback
        currentEmail = ''; // Clear the stored email
        tempEmailAddressElement.textContent = 'No active address'; // Update display
        clearInboxDisplay();
        // In a real app, you'd also call a DELETE API endpoint here.
    }


    // --- Event Listeners ---
    copyButton.addEventListener('click', copyEmailToClipboard);
    copyButtonAlt.addEventListener('click', copyEmailToClipboard); // Wire up the second button

    refreshButton.addEventListener('click', refreshInbox);
    changeButton.addEventListener('click', changeEmailAddress);
    deleteButton.addEventListener('click', deleteEmailAddress);


    // --- Initial Setup ---
    const initialEmail = generateNewEmailAddress();
    displayEmailAddress(initialEmail);
    console.log('Initial email generated:', initialEmail);
    // Optionally, you could trigger an initial inbox refresh here:
    // refreshInbox();

}); // End of DOMContentLoaded